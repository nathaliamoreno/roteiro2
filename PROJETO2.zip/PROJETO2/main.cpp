#include <iostream>
#include <string>
#include <cstdlib>
#include "Endereco.h"
#include "Casa.h"
#include "Apartamento.h"
#include "Terreno.h"
#include "Imovel.h"


using namespace std;


int main()
{

    int op, i=0;
    Imovel imovel;
    Endereco e;

    i = imovel.lerDados(); //ler os dados e retorna a posicao

    cout << "\n       S I S T E M A  D E  G E R E N C I A M E N T O \n                     D E  I M O V E I S" << endl;
    cout << "____________________________________________________________________"<< endl;

    while(1){

        imovel.ExibeMenu();
        cin >> op;
        system("cls");
    if(op == 1)
    {
        int s;
        imovel.Cadastro(i);
        i++;



    }else if (op == 2){

        imovel.ExibeSubMenu();
        cin >> op;

        if (op == 1){
            system("cls");
            cout << "LISTA DE IMOVEIS " << endl;
            imovel.ExibeLista(i);

        }else if (op == 2){
            system("cls");
            imovel.PorTipo(i);

        }else if (op == 3){
            system("cls");
            imovel.PorStatus(i);

        }else if(op == 4){
            system("cls");
            imovel.PorBairro(i);
        }else if (op == 5){
            system("cls");
            imovel.PorCidade(i);
        }else if (op == 6){
            system("cls");
            imovel.PorValor(i);

        }else if(op == 7){
            imovel.ExibeMenu();

        }
    }else if(op == 3){
        int sel;
        system("cls");

        cout << "\n\n BUSQUE PELO IMOVEL QUE DESEJA EDITAR" << endl;
        cout << "\n  De qual forma deseja pesquisar?" << endl;
        imovel.ExibeSubMenu();
        cin >> sel;
        system("cls");
        if (sel == 1){

            cout << "\nLISTA DE IMOVEIS " << endl;
            imovel.ExibeLista(i);

        }else if (sel == 2){

            imovel.PorTipo(i);

        }else if (sel == 3){

            imovel.PorStatus(i);

        }else if(sel == 4){

            imovel.PorBairro(i);
        }else if (sel == 5){

            imovel.PorCidade(i);

        }else if (sel== 6){

            imovel.PorValor(i);

         }else if(op == 7){

            imovel.ExibeMenu();
         }
        cout << "\n\nQUAL IMOVEL DESEJA EDITAR?"<< endl;
        cout << " Digite o numero correspondente ao imovel que deseja excluir" << endl;
        cin >> sel;
        imovel.Edita(sel);

    }else if(op == 4){
        int sel;
        system("cls");
        cout << "\n\n BUSQUE PELO IMOVEL QUE DESEJA EXCLUIR" << endl;
        cout << "\n  De qual forma deseja pesquisar?" << endl;
        imovel.ExibeSubMenu();
        cin >> sel;

        if (sel == 1){
            cout << "\nLISTA DE IMOVEIS " << endl;
            imovel.ExibeLista(i);

        }else if (sel == 2){

            imovel.PorTipo(i);

        }else if (sel == 3){

            imovel.PorStatus(i);

        }else if(sel == 4){

            imovel.PorBairro(i);
        }else if (sel == 5){

            imovel.PorCidade(i);
        }else if (sel== 6){

            imovel.PorValor(i);
         }else if(op == 7){

            imovel.ExibeMenu();
         }
        cout << "\n\nQUAL IMOVEL DESEJA EXCLUIR?"<< endl;
        cout << " Digite o numero correspondente ao imovel que deseja excluir" << endl;
        cin >> sel;
        imovel.ExcluirImovel(sel);


    }else if(op == 0 || !op){

        imovel.salvaDados(i);
        return 0;
        //imovel.salvaDados(i);
    }
}//encerra loop while
}//encerra main
