#include "Casa.h"

Casa::Casa()
{

}

Casa::Casa(int pav, int quartos, double aTer, double aConst)
{
    nPav = pav;
    nQuartos = quartos;
    areaTer = aTer;
    areaConstr = aConst;
}
void Casa::setPavimentos(int pav){
    nPav = pav;
}
void Casa::setQuartos(int quartos){
    nQuartos = quartos;
}
void Casa::setAreaTerreno(double aTer){
    areaTer = aTer;
}
void Casa::setAreaConstruida(double aConst){
    areaConstr = aConst;
}
int Casa::getPavimentos(){
    return nPav;
}
int Casa::getQuartos(){
    return nQuartos;
}
double Casa::getAreaTerreno(){
    return areaTer;
}
double Casa::getAreaConstruida(){
    return areaConstr;
}
