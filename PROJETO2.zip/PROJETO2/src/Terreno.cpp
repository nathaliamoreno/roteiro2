#include "Terreno.h"

Terreno::Terreno()
{

}

Terreno::Terreno(double area)
{
    areaT = area;
}
void Terreno::setAreaT(double area){
    areaT = area;
}
double Terreno::getAreaT(){
    return areaT;
}
