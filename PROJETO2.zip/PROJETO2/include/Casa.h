#ifndef CASA_H
#define CASA_H
#include "Endereco.h"

class Casa : public Endereco
{
    public:
        Casa();
        Casa(int pav, int quartos, double aTer, double aConst);

        void setPavimentos(int pav);
        void setQuartos(int quartos);
        void setAreaTerreno(double aTer);
        void setAreaConstruida(double aConst);

        int getPavimentos();
        int getQuartos();
        double getAreaTerreno();
        double getAreaConstruida();

        int nPav;
        int nQuartos;
        double areaTer;
        double areaConstr;

    private:

};

#endif // CASA_H
